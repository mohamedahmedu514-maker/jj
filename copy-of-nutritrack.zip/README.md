# NutriTrack - GitHub & Vercel Deployment Guide

This guide will show you how to publish your NutriTrack system to a live, public website using GitHub and Vercel. This is the recommended method because it allows you to easily update your website in the future.

You will only need to do this once.

---

### Part 1: Put Your Project on GitHub

We will use **GitHub Desktop**, a free and simple application that avoids any complex commands.

1.  **Download GitHub Desktop:**
    *   Go to **[desktop.github.com](https://desktop.github.com/)** and download the application for Windows or Mac.
    *   Install and open it.

2.  **Sign in to GitHub:**
    *   If you don't have a GitHub account, you can create one for free.
    *   In the GitHub Desktop app, sign in with your GitHub account email and password.

3.  **Create a Repository for Your Project:**
    *   In the app, click **"Create a New Repository on your Hard Drive..."**.
    *   **Name:** Give your project a simple name, like `nutritrack-system`.
    *   **Local Path:** Click "Choose..." and select the folder on your computer that contains all your project files (`index.html`, `App.tsx`, etc.).
    *   Click the **"Create Repository"** button.

4.  **Publish Your Project:**
    *   The app will now show all your project files. At the bottom, you'll see a "Summary" box.
    *   In the summary box, type a short message like `Initial commit`.
    *   Click the blue **"Commit to main"** button.
    *   Now, at the top of the window, click the blue **"Publish repository"** button.
    *   A new window will pop up. Make sure the "Keep this code private" box is **unchecked** (so Vercel can see it).
    *   Click **"Publish Repository"**.

**Congratulations!** Your project code is now saved to your GitHub account online.

---

### Part 2: Deploy to Vercel from GitHub

Now we will connect Vercel to your new GitHub repository.

1.  **Go to Vercel:**
    *   Open your web browser and go to **[https://vercel.com/new](https://vercel.com/new)**.

2.  **Import Your Project:**
    *   Instead of dragging a file, look for the **"Continue with GitHub"** option and click it.
    *   Vercel will ask for permission to view your GitHub repositories. Allow it.
    *   You should now see a list of your GitHub projects. Find the `nutritrack-system` repository you just created and click the **"Import"** button next to it.

3.  **Deploy:**
    *   Vercel will automatically detect all the settings. You do not need to change anything.
    *   Just scroll down and click the **"Deploy"** button.

### All Done!

After about a minute, Vercel will give you a public URL. Your NutriTrack system is now live!

**The Best Part:** From now on, whenever you make changes to your files, you can just open the GitHub Desktop app, write a summary of your changes, click "Commit", and then click "Push". Vercel will **automatically update your live website** with the new changes.
