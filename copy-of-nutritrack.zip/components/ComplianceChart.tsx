// NutriTrack Health Management System - Created by Anas Bahaa
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';
import { ProgressEntry } from '../types';
import Icons from './Icons';
import { translations, Language } from '../translations';

interface ComplianceChartProps {
  history: ProgressEntry[];
  lang: Language;
}

const CustomTooltip = ({ active, payload, label, lang }: any) => {
  if (active && payload && payload.length) {
    const t = translations[lang];
    return (
      <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm p-2 border border-gray-300 dark:border-slate-600 rounded-md shadow-lg">
        <p className="label font-semibold text-foreground dark:text-dark-foreground">{`${t.progressChart.date} : ${label}`}</p>
        <p className="intro text-purple-500">{`${t.complianceChart.compliance} : ${payload[0].value}%`}</p>
      </div>
    );
  }
  return null;
};

const ComplianceChart: React.FC<ComplianceChartProps> = ({ history, lang }) => {
  const t = translations[lang];

  const formattedHistory = history.map(entry => ({
    ...entry,
    date: new Date(entry.date).toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US', { month: 'short', day: 'numeric' }),
  }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4, duration: 0.5 }}
      className="bg-background dark:bg-dark-secondary p-6 rounded-2xl shadow-md"
    >
      <div className="flex items-center mb-4">
        <Icons.ClipboardCheck className="h-6 w-6 text-primary me-3" />
        <h3 className="text-xl font-bold text-foreground dark:text-dark-foreground">{t.complianceChart.title}</h3>
      </div>
      {history.filter(h => h.compliance).length > 1 ? (
        <div className="h-80" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={formattedHistory} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)" />
              <XAxis dataKey="date" tick={{ fill: 'rgb(100 116 139)' }} fontSize={12} />
              <YAxis domain={[0, 100]} unit="%" tick={{ fill: 'rgb(100 116 139)' }} fontSize={12} />
              <Tooltip content={<CustomTooltip lang={lang} />} />
              <Legend />
              <Bar dataKey="compliance" fill="rgb(168 85 247)" name={`${t.complianceChart.compliance} (%)`} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <div className="h-80 flex flex-col items-center justify-center text-center text-gray-500 dark:text-gray-400">
          <Icons.PersonStanding className="h-16 w-16 text-primary mb-4" />
          <p className="font-semibold">{t.complianceChart.empty.title}</p>
          <p className="text-sm">{t.complianceChart.empty.subtitle}</p>
        </div>
      )}
    </motion.div>
  );
};

export default ComplianceChart;