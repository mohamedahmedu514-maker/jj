import React, { useState, useMemo } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

import { UserData, UserRole, ProgressEntry, DietPlan, Appointment } from '../types';
import { PatientProfile } from '../db';
import { calculateBMI, calculateDailyCalories, getBMICategory } from '../utils/calculations';

import Header from './Header';
import BMICard from './BMICard';
import CaloriesCard from './CaloriesCard';
import WaterIntakeCard from './WaterIntakeCard';
import ProgressCharts from './ProgressCharts';
import DietPlanDisplay from './DietPlanDisplay';
import UpdateWeightModal from './UpdateWeightModal';
import EditProfileModal from './EditProfileModal';
import EditDietPlanModal from './EditDietPlanModal';
import ComplianceChart from './ComplianceChart';
import FeedbackModal from './FeedbackModal';
import OnboardingGuide from './OnboardingGuide';
import AppointmentsCard from './AppointmentsCard';
import ScheduleAppointmentModal from './ScheduleAppointmentModal';
import { translations, Language } from '../translations';


interface DashboardProps {
  patientProfile: PatientProfile;
  userRole: UserRole;
  onUpdateProfile: (updatedProfile: PatientProfile) => void;
  onLogout: () => void;
  onBackToPatients?: () => void;
  onBack?: () => void;
  showOnboarding: boolean;
  onOnboardingComplete: () => void;
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  lang: Language;
  setLang: (lang: Language) => void;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
        type: 'spring',
        stiffness: 100,
    }
  },
};


const Dashboard: React.FC<DashboardProps> = ({ patientProfile, userRole, onUpdateProfile, onLogout, onBackToPatients, onBack, showOnboarding, onOnboardingComplete, theme, setTheme, lang, setLang }) => {
  const [isUpdateWeightModalOpen, setUpdateWeightModalOpen] = useState(false);
  const [isEditProfileModalOpen, setEditProfileModalOpen] = useState(false);
  const [isEditDietPlanModalOpen, setEditDietPlanModalOpen] = useState(false);
  const [isFeedbackModalOpen, setFeedbackModalOpen] = useState(false);
  const [isScheduleModalOpen, setScheduleModalOpen] = useState(false);
  
  const [isExportingPDF, setIsExportingPDF] = useState(false);

  const { data: userData, progressHistory, dietPlan, appointments } = patientProfile;
  
  const dailyCalories = useMemo(() => calculateDailyCalories(userData), [userData]);
  const bmi = useMemo(() => progressHistory.length > 0 ? progressHistory[progressHistory.length - 1].bmi : 0, [progressHistory]);
  const bmiCategory = useMemo(() => getBMICategory(bmi), [bmi]);
  
  const latestProgress = progressHistory.length > 0 ? progressHistory[progressHistory.length - 1] : null;
  const currentWaterIntake = latestProgress?.waterIntake ?? 0;

  const t = translations[lang];
  const onboardingSteps = userRole === UserRole.DOCTOR ? t.onboarding.doctor : t.onboarding.patient;

  const isToday = (someDateString: string) => {
    if (!someDateString) return false;
    const today = new Date();
    const someDate = new Date(someDateString);
    return someDate.getDate() === today.getDate() &&
           someDate.getMonth() === today.getMonth() &&
           someDate.getFullYear() === today.getFullYear();
  };

  const handleUpdateWater = (amount: number) => {
    let updatedHistory = [...progressHistory];
    const lastEntry = updatedHistory.length > 0 ? updatedHistory[updatedHistory.length - 1] : null;

    if (lastEntry && isToday(lastEntry.date)) {
        lastEntry.waterIntake = (lastEntry.waterIntake || 0) + amount;
    } else {
        const newEntry: ProgressEntry = {
            date: new Date().toISOString(),
            weight: lastEntry ? lastEntry.weight : userData.weight,
            bmi: lastEntry ? lastEntry.bmi : calculateBMI(userData.weight, userData.height),
            compliance: lastEntry ? lastEntry.compliance : undefined,
            waterIntake: amount,
        };
        updatedHistory.push(newEntry);
    }

    onUpdateProfile({ ...patientProfile, progressHistory: updatedHistory });
  };

  const handleUpdateWeight = (newWeight: number) => {
    const newEntry: ProgressEntry = {
      date: new Date().toISOString(),
      weight: newWeight,
      bmi: calculateBMI(newWeight, userData.height),
      compliance: Math.floor(Math.random() * (98 - 75 + 1) + 75),
      waterIntake: 0,
    };
    
    const updatedProfile: PatientProfile = {
        ...patientProfile,
        data: { ...userData, weight: newWeight },
        progressHistory: [...progressHistory, newEntry],
    };
    onUpdateProfile(updatedProfile);
    setUpdateWeightModalOpen(false);
  };
  
  const handleUpdateProfile = (newUserData: UserData) => {
      let updatedProgressHistory = progressHistory;
      const latestWeight = progressHistory.length > 0 ? progressHistory[progressHistory.length - 1].weight : userData.weight;

      if(newUserData.weight !== latestWeight) {
        const newEntry: ProgressEntry = {
            date: new Date().toISOString(),
            weight: newUserData.weight,
            bmi: calculateBMI(newUserData.weight, newUserData.height),
            compliance: Math.floor(Math.random() * (98 - 75 + 1) + 75),
            waterIntake: 0,
        };
        updatedProgressHistory = [...progressHistory, newEntry];
      }

      const updatedProfile: PatientProfile = {
        ...patientProfile,
        data: newUserData,
        progressHistory: updatedProgressHistory
      };
      onUpdateProfile(updatedProfile);
      setEditProfileModalOpen(false);
  }

  const handleSaveDietPlan = (newPlan: DietPlan) => {
    onUpdateProfile({ ...patientProfile, dietPlan: newPlan });
    setEditDietPlanModalOpen(false);
  };

  const handleScheduleAppointment = (appointment: Omit<Appointment, 'id'>) => {
    const newAppointment: Appointment = {
      ...appointment,
      id: Date.now(),
    };
    const updatedAppointments = [...(patientProfile.appointments || []), newAppointment];
    onUpdateProfile({ ...patientProfile, appointments: updatedAppointments });
    setScheduleModalOpen(false);
  };


  const handleExportPDF = () => {
    setIsExportingPDF(true);
    const input = document.getElementById('pdf-export-content');
    if (input) {
      html2canvas(input, { scale: 2, useCORS: true }).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const canvasWidth = canvas.width;
        const canvasHeight = canvas.height;
        const ratio = canvasWidth / canvasHeight;
        let width = pdfWidth;
        let height = width / ratio;

        if (height > pdfHeight) {
          height = pdfHeight;
          width = height * ratio;
        }

        const x = (pdfWidth - width) / 2;
        const y = 0;
        
        pdf.addImage(imgData, 'PNG', x, y, width, height);
        pdf.save(`${userData.name}-NutriTrack-Report.pdf`);
        setIsExportingPDF(false);
      }).catch(err => {
        console.error("Error exporting PDF:", err);
        setIsExportingPDF(false);
      });
    } else {
        setIsExportingPDF(false);
    }
  };

  return (
    <div className="min-h-screen p-4">
      <OnboardingGuide
        steps={onboardingSteps}
        isOpen={showOnboarding}
        onComplete={onOnboardingComplete}
        lang={lang}
      />
       <Header
          userData={userData}
          userRole={userRole}
          onUpdateWeight={() => setUpdateWeightModalOpen(true)}
          onEditProfile={() => setEditProfileModalOpen(true)}
          onLogout={onLogout}
          onOpenFeedback={() => setFeedbackModalOpen(true)}
          onExportPDF={handleExportPDF}
          isExportingPDF={isExportingPDF}
          onBackToPatients={onBackToPatients}
          onBack={onBack}
          theme={theme}
          setTheme={setTheme}
          lang={lang}
          setLang={setLang}
        />
      <div id="pdf-export-content" className="bg-secondary dark:bg-dark-background p-4 -m-4 mt-0">
        <motion.div
          className="flex flex-col space-y-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
            <motion.div variants={itemVariants}><BMICard bmi={bmi} category={bmiCategory} lang={lang} /></motion.div>
            <motion.div variants={itemVariants}><CaloriesCard calories={dailyCalories} lang={lang} /></motion.div>
             <motion.div variants={itemVariants}>
                <AppointmentsCard
                    appointments={appointments || []}
                    userRole={userRole}
                    onScheduleNew={() => setScheduleModalOpen(true)}
                    lang={lang}
                />
            </motion.div>
            <motion.div variants={itemVariants}>
                <WaterIntakeCard
                  currentIntake={currentWaterIntake}
                  goal={userData.waterGoal}
                  onAddWater={handleUpdateWater}
                  lang={lang}
                />
            </motion.div>
            <motion.div variants={itemVariants}><ProgressCharts history={progressHistory} lang={lang} /></motion.div>
            {userRole === UserRole.DOCTOR && <motion.div variants={itemVariants}><ComplianceChart history={progressHistory} lang={lang} /></motion.div>}
             <motion.div variants={itemVariants}>
                <DietPlanDisplay
                  plan={dietPlan}
                  userRole={userRole}
                  onEdit={() => setEditDietPlanModalOpen(true)}
                  lang={lang}
                />
            </motion.div>
        </motion.div>
      </div>
      
      <AnimatePresence>
        {isUpdateWeightModalOpen && (
          <UpdateWeightModal
            onClose={() => setUpdateWeightModalOpen(false)}
            onUpdate={handleUpdateWeight}
            currentWeight={userData.weight}
            lang={lang}
          />
        )}
        {isEditProfileModalOpen && (
            <EditProfileModal
                onClose={() => setEditProfileModalOpen(false)}
                onUpdate={handleUpdateProfile}
                currentUserData={userData}
                lang={lang}
            />
        )}
        {isEditDietPlanModalOpen && userRole === UserRole.DOCTOR && (
          <EditDietPlanModal
            onClose={() => setEditDietPlanModalOpen(false)}
            onSave={handleSaveDietPlan}
            currentPlan={dietPlan}
            lang={lang}
          />
        )}
         {isScheduleModalOpen && userRole === UserRole.DOCTOR && (
          <ScheduleAppointmentModal
            patientName={userData.name}
            onClose={() => setScheduleModalOpen(false)}
            onSchedule={handleScheduleAppointment}
            lang={lang}
          />
        )}
        {isFeedbackModalOpen && (
          <FeedbackModal
            onClose={() => setFeedbackModalOpen(false)}
            userData={userData}
            lang={lang}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default Dashboard;