// NutriTrack Health Management System - Created by Anas Bahaa
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UserData, UserRole } from '../types';
import Icons from './Icons';
import { translations, Language } from '../translations';

interface HeaderProps {
  userData: UserData;
  userRole: UserRole;
  onUpdateWeight: () => void;
  onEditProfile: () => void;
  onLogout: () => void;
  onOpenFeedback: () => void;
  onExportPDF: () => void;
  isExportingPDF: boolean;
  onBackToPatients?: () => void;
  onBack?: () => void;
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  lang: Language;
  setLang: (lang: Language) => void;
}

const Header: React.FC<HeaderProps> = ({
  userData,
  userRole,
  onUpdateWeight,
  onEditProfile,
  onLogout,
  onOpenFeedback,
  onBackToPatients,
  onExportPDF,
  isExportingPDF,
  onBack,
  theme,
  setTheme,
  lang,
  setLang
}) => {
    const [menuOpen, setMenuOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    const t = translations[lang];

    const toggleTheme = () => {
        setTheme(theme === 'light' ? 'dark' : 'light');
    };
    
    const toggleLanguage = () => {
        setLang(lang === 'en' ? 'ar' : 'en');
    };

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setMenuOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [menuRef]);

  return (
    <header className="bg-background dark:bg-dark-secondary p-4 flex justify-between items-center shadow-sm rounded-2xl mb-6">
      <div className="flex items-center">
        {(onBackToPatients || onBack) && (
             <button
                onClick={onBackToPatients || onBack}
                className="flex items-center p-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-full"
                style={{ margin: lang === 'en' ? '0 0.5rem 0 0' : '0 0 0 0.5rem' }}
            >
                 <Icons.ArrowLeft className={`h-5 w-5 ${lang === 'ar' ? 'transform rotate-180' : ''}`} />
            </button>
        )}
        <div>
            {userRole === UserRole.DOCTOR && (
                <p className="text-sm font-semibold text-primary">{t.doctorName}</p>
            )}
            <h1 className="text-lg font-bold text-foreground dark:text-dark-foreground leading-tight">
                {userRole === UserRole.DOCTOR ? `${t.header.patient}: ${userData.name}`: t.header.myDashboard}
            </h1>
        </div>
      </div>
      <div className="flex items-center space-x-2">
         <button
          onClick={onUpdateWeight}
          className="flex items-center px-3 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md"
        >
          <Icons.Plus className="h-4 w-4 sm:mr-2" />
          <span className="hidden sm:inline">{t.header.updateWeight}</span>
        </button>
        
        <button onClick={toggleTheme} className="p-2 rounded-full text-gray-500 hover:bg-gray-200 dark:text-gray-400 dark:hover:bg-slate-700">
            {theme === 'light' ? <Icons.Moon className="h-5 w-5" /> : <Icons.Sun className="h-5 w-5" />}
        </button>

        <button onClick={toggleLanguage} className="p-2 rounded-full text-gray-500 hover:bg-gray-200 dark:text-gray-400 dark:hover:bg-slate-700 font-bold text-sm">
            {lang === 'en' ? 'ع' : 'EN'}
        </button>

        <div className="relative" ref={menuRef}>
            <button onClick={() => setMenuOpen(!menuOpen)} className="p-2 rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-slate-700">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/></svg>
            </button>
            <AnimatePresence>
            {menuOpen && (
                <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: -10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: -10 }}
                    transition={{ duration: 0.1 }}
                    className="absolute right-0 mt-2 w-48 bg-background dark:bg-dark-secondary rounded-md shadow-lg z-10 border border-gray-200 dark:border-slate-700"
                >
                    <button onClick={() => { onEditProfile(); setMenuOpen(false); }} className="w-full text-left flex items-center px-4 py-2 text-sm text-foreground dark:text-dark-foreground hover:bg-gray-100 dark:hover:bg-slate-700">
                        <Icons.User className="h-4 w-4 mr-2" /> {t.header.editProfile}
                    </button>
                    <button onClick={() => { onExportPDF(); setMenuOpen(false); }} disabled={isExportingPDF} className="w-full text-left flex items-center px-4 py-2 text-sm text-foreground dark:text-dark-foreground hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50">
                        {isExportingPDF ? <Icons.RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Icons.FileDown className="h-4 w-4 mr-2" />}
                        {isExportingPDF ? t.header.exporting : t.header.exportPdf}
                    </button>
                    <button onClick={() => { onOpenFeedback(); setMenuOpen(false); }} className="w-full text-left flex items-center px-4 py-2 text-sm text-foreground dark:text-dark-foreground hover:bg-gray-100 dark:hover:bg-slate-700">
                        <Icons.MessageSquare className="h-4 w-4 mr-2" /> {t.header.feedback}
                    </button>
                    <div className="border-t border-gray-200 dark:border-slate-700 my-1"></div>
                    <button onClick={() => { onLogout(); setMenuOpen(false); }} className="w-full text-left flex items-center px-4 py-2 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10">
                        <Icons.LogOut className="h-4 w-4 mr-2" /> {t.header.logout}
                    </button>
                </motion.div>
            )}
            </AnimatePresence>
        </div>
      </div>
    </header>
  );
};

export default Header;