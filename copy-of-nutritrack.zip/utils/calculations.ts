// NutriTrack Health Management System - Created by Anas Bahaa
import { UserData, Gender, ActivityLevel } from '../types';
import { ACTIVITY_MULTIPLIERS, BMI_CATEGORIES } from '../constants';

export const calculateBMI = (weight: number, height: number): number => {
  if (height <= 0) return 0;
  const heightInMeters = height / 100;
  const bmi = weight / (heightInMeters * heightInMeters);
  return parseFloat(bmi.toFixed(2));
};

export const getBMICategory = (bmi: number) => {
  for (const category of Object.values(BMI_CATEGORIES)) {
    if (bmi >= category.range[0] && bmi < category.range[1]) {
      return category;
    }
  }
  return BMI_CATEGORIES.OBESE;
};

export const calculateBMR = (userData: UserData): number => {
  const { weight, height, age, gender } = userData;
  if (gender === Gender.MALE) {
    return 88.362 + 13.397 * weight + 4.799 * height - 5.677 * age;
  } else {
    return 447.593 + 9.247 * weight + 3.098 * height - 4.330 * age;
  }
};

export const calculateDailyCalories = (userData: UserData): number => {
  const bmr = calculateBMR(userData);
  const activityMultiplier = ACTIVITY_MULTIPLIERS[userData.activityLevel];
  return Math.round(bmr * activityMultiplier);
};