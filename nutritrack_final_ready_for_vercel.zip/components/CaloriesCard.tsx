// NutriTrack Health Management System - Created by Anas Bahaa
import React from 'react';
import { motion } from 'framer-motion';
import Icons from './Icons';
import { translations, Language } from '../translations';

interface CaloriesCardProps {
  calories: number;
  lang: Language;
}

const CaloriesCard: React.FC<CaloriesCardProps> = ({ calories, lang }) => {
  const t = translations[lang];

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-background dark:bg-dark-secondary p-6 rounded-2xl shadow-md"
    >
      <div className="flex items-center mb-4">
        <div className="bg-primary/10 text-primary p-3 rounded-full me-4">
          <Icons.Zap className="h-6 w-6" />
        </div>
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">{t.caloriesCard.dailyGoal}</p>
          <p className="text-3xl font-bold text-foreground dark:text-dark-foreground">{calories}</p>
        </div>
      </div>
      <p className="text-lg font-semibold text-foreground dark:text-dark-foreground">{t.caloriesCard.caloriesDay}</p>
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{t.caloriesCard.suggestion}</p>
    </motion.div>
  );
};

export default CaloriesCard;