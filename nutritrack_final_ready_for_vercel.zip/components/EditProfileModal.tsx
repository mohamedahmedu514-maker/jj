// NutriTrack Health Management System - Created by Anas Bahaa
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icons from './Icons';
import { UserData, Gender, ActivityLevel } from '../types';
import { ACTIVITY_LEVEL_OPTIONS } from '../constants';
import { translations, Language } from '../translations';

interface EditProfileModalProps {
  onClose: () => void;
  onUpdate: (newUserData: UserData) => void;
  currentUserData: UserData;
  lang: Language;
}

const EditProfileModal: React.FC<EditProfileModalProps> = ({ onClose, onUpdate, currentUserData, lang }) => {
  const [formData, setFormData] = useState<UserData>(currentUserData);
  const t = translations[lang];

  const translatedActivityOptions = [
    { value: ActivityLevel.SEDENTARY, label: t.activityLevels.sedentary },
    { value: ActivityLevel.LIGHTLY_ACTIVE, label: t.activityLevels.lightly },
    { value: ActivityLevel.MODERATE, label: t.activityLevels.moderate },
    { value: ActivityLevel.VERY_ACTIVE, label: t.activityLevels.very },
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    const numericFields = ['height', 'age', 'waterGoal'];
    setFormData(prev => ({ ...prev, [name]: numericFields.includes(name) ? Number(value) : value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate(formData);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: -20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: -20 }}
        className="bg-background dark:bg-dark-secondary rounded-2xl shadow-xl w-full max-w-md p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-foreground dark:text-dark-foreground">{t.editProfileModal.title}</h2>
          <button onClick={onClose} className="p-1 rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-slate-700">
            <Icons.X className="h-5 w-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.name}</label>
              <input type="text" name="name" value={formData.name} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.age}</label>
              <input type="number" name="age" value={formData.age} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.height}</label>
              <input type="number" name="height" value={formData.height} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
            </div>
             <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.gender}</label>
                <select name="gender" onChange={handleChange} value={formData.gender} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary">
                <option value={Gender.MALE}>{t.form.male}</option>
                <option value={Gender.FEMALE}>{t.form.female}</option>
                </select>
            </div>
          </div>
           <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.waterGoal}</label>
            <input type="number" name="waterGoal" value={formData.waterGoal} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
          </div>
           <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.activityLevel}</label>
            <select name="activityLevel" onChange={handleChange} value={formData.activityLevel} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary">
              {translatedActivityOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
            </select>
          </div>

          <div className="mt-6 flex justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-slate-700">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-md">
              {t.common.cancel}
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md">
              {t.common.saveChanges}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default EditProfileModal;