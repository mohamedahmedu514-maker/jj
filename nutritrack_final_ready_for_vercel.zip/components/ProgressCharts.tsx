// NutriTrack Health Management System - Created by Anas Bahaa
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { motion } from 'framer-motion';
import { ProgressEntry } from '../types';
import Icons from './Icons';
import { translations, Language } from '../translations';


const CustomTooltip = ({ active, payload, label, lang }: any) => {
  if (active && payload && payload.length) {
    const t = translations[lang];
    return (
      <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm p-2 border border-gray-300 dark:border-slate-600 rounded-md shadow-lg">
        <p className="label font-semibold text-foreground dark:text-dark-foreground">{`${t.progressChart.date}: ${label}`}</p>
        <p className="intro text-green-500">{`${t.progressChart.weight}: ${payload[0].value} ${t.progressChart.kg}`}</p>
        <p className="intro text-blue-500">{`${t.progressChart.bmi}: ${payload[1].value}`}</p>
      </div>
    );
  }
  return null;
};


const ProgressCharts: React.FC<{ history: ProgressEntry[]; lang: Language }> = ({ history, lang }) => {
  const t = translations[lang];

  const formattedHistory = history.map(entry => ({
    ...entry,
    date: new Date(entry.date).toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US', { month: 'short', day: 'numeric' }),
  }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2, duration: 0.5 }}
      className="bg-background dark:bg-dark-secondary p-6 rounded-2xl shadow-md"
    >
      <div className="flex items-center mb-4">
        <Icons.BarChart3 className="h-6 w-6 text-primary me-3" />
        <h3 className="text-xl font-bold text-foreground dark:text-dark-foreground">{t.progressChart.title}</h3>
      </div>
      {history.length > 1 ? (
        <div className="h-80" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={formattedHistory} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)" />
              <XAxis dataKey="date" tick={{ fill: 'rgb(100 116 139)' }} fontSize={12} />
              <YAxis yAxisId="left" stroke="rgb(34 197 94)" tick={{ fill: 'rgb(100 116 139)' }} fontSize={12} />
              <YAxis yAxisId="right" orientation="right" stroke="rgb(59 130 246)" tick={{ fill: 'rgb(100 116 139)' }} fontSize={12} />
              <Tooltip content={<CustomTooltip lang={lang} />} />
              <Legend />
               <defs>
                    <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="rgb(34 197 94)" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="rgb(34 197 94)" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorBmi" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="rgb(59 130 246)" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="rgb(59 130 246)" stopOpacity={0}/>
                    </linearGradient>
                </defs>
              <Area type="monotone" dataKey="weight" yAxisId="left" stroke="rgb(34 197 94)" strokeWidth={2} fillOpacity={1} fill="url(#colorWeight)" name={`${t.progressChart.weight} (${t.progressChart.kg})`} />
              <Area type="monotone" dataKey="bmi" yAxisId="right" stroke="rgb(59 130 246)" strokeWidth={2} fillOpacity={1} fill="url(#colorBmi)" name={t.progressChart.bmi} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <div className="h-80 flex flex-col items-center justify-center text-center text-gray-500 dark:text-gray-400">
           <Icons.Trophy className="h-16 w-16 text-primary mb-4" />
          <p className="font-semibold">{t.progressChart.empty.title}</p>
          <p className="text-sm">{t.progressChart.empty.subtitle}</p>
        </div>
      )}
    </motion.div>
  );
};

export default ProgressCharts;