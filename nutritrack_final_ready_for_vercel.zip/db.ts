// NutriTrack Health Management System - Created by Anas Bahaa
import { UserData, ProgressEntry, Gender, ActivityLevel, DietPlan, Appointment } from './types';

export interface PatientProfile {
  data: UserData;
  progressHistory: ProgressEntry[];
  dietPlan: DietPlan | null;
  appointments?: Appointment[];
}

export const db: PatientProfile[] = [
  {
    data: {
      id: 1,
      name: 'John Doe',
      age: 45,
      gender: Gender.MALE,
      height: 180,
      weight: 85,
      activityLevel: ActivityLevel.LIGHTLY_ACTIVE,
      waterGoal: 2500,
    },
    progressHistory: [
      { date: '2023-10-01T10:00:00Z', weight: 90, bmi: 27.78, compliance: 85, waterIntake: 1500 },
      { date: '2023-10-08T10:00:00Z', weight: 89, bmi: 27.47, compliance: 90, waterIntake: 1750 },
      { date: '2023-10-15T10:00:00Z', weight: 87, bmi: 26.85, compliance: 88, waterIntake: 1600 },
      { date: '2023-10-22T10:00:00Z', weight: 86, bmi: 26.54, compliance: 92, waterIntake: 2000 },
      { date: '2023-10-29T10:00:00Z', weight: 85, bmi: 26.23, compliance: 95, waterIntake: 2200 },
    ],
    dietPlan: null,
    appointments: [],
  },
  {
    data: {
      id: 2,
      name: 'Jane Smith',
      age: 32,
      gender: Gender.FEMALE,
      height: 165,
      weight: 60,
      activityLevel: ActivityLevel.MODERATE,
      waterGoal: 2000,
    },
    progressHistory: [
      { date: '2023-10-01T10:00:00Z', weight: 62, bmi: 22.77, compliance: 95, waterIntake: 1800 },
      { date: '2023-10-08T10:00:00Z', weight: 61.5, bmi: 22.59, compliance: 98, waterIntake: 1900 },
      { date: '2023-10-15T10:00:00Z', weight: 61, bmi: 22.41, compliance: 96, waterIntake: 2000 },
      { date: '2023-10-22T10:00:00Z', weight: 60.5, bmi: 22.22, compliance: 97, waterIntake: 1950 },
      { date: '2023-10-29T10:00:00Z', weight: 60, bmi: 22.04, compliance: 99, waterIntake: 2100 },
    ],
    dietPlan: null,
    appointments: [],
  },
  {
    data: {
        id: 3,
        name: 'Mike Johnson',
        age: 55,
        gender: Gender.MALE,
        height: 175,
        weight: 102,
        activityLevel: ActivityLevel.SEDENTARY,
        waterGoal: 3000,
    },
    progressHistory: [
        { date: '2023-10-01T10:00:00Z', weight: 105, bmi: 34.29, compliance: 70, waterIntake: 1200 },
        { date: '2023-10-08T10:00:00Z', weight: 104, bmi: 33.96, compliance: 72, waterIntake: 1400 },
        { date: '2023-10-15T10:00:00Z', weight: 103, bmi: 33.63, compliance: 75, waterIntake: 1300 },
        { date: '2023-10-22T10:00:00Z', weight: 102.5, bmi: 33.47, compliance: 78, waterIntake: 1500 },
        { date: '2023-10-29T10:00:00Z', weight: 102, bmi: 33.31, compliance: 80, waterIntake: 1600 },
    ],
    dietPlan: null,
    appointments: [],
  },
];