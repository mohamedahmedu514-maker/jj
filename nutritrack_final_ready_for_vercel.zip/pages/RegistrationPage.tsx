// NutriTrack Health Management System - Created by Anas Bahaa
import React, { useState } from 'react';
import { UserData, Gender, ActivityLevel } from '../types';
import Icons from '../components/Icons';
import { translations, Language } from '../translations';


interface RegistrationPageProps {
  onSubmit: (data: Omit<UserData, 'id' | 'weight'> & { weight: number }) => void;
  onCancel?: () => void;
  onBackToLogin?: () => void;
  lang: Language;
  setLang: (lang: Language) => void;
}

const RegistrationPage: React.FC<RegistrationPageProps> = ({ onSubmit, onCancel, onBackToLogin, lang, setLang }) => {
  const [formData, setFormData] = useState({
    name: 'John Doe',
    age: 30,
    gender: Gender.MALE,
    height: 175,
    weight: 70,
    activityLevel: ActivityLevel.MODERATE,
  });
  
  const t = translations[lang];
  
  const translatedActivityOptions = [
    { value: ActivityLevel.SEDENTARY, label: t.activityLevels.sedentary },
    { value: ActivityLevel.LIGHTLY_ACTIVE, label: t.activityLevels.lightly },
    { value: ActivityLevel.MODERATE, label: t.activityLevels.moderate },
    { value: ActivityLevel.VERY_ACTIVE, label: t.activityLevels.very },
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'height' || name === 'age' || name === 'weight' ? Number(value) : value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  const toggleLanguage = () => {
    setLang(lang === 'en' ? 'ar' : 'en');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-secondary dark:bg-dark-background p-4 relative">
      <div className="absolute top-8 start-8 text-start">
        <h2 className="text-xl font-bold text-primary">{t.doctorName}</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">{t.systemName}</p>
      </div>
      <div className="absolute top-8 end-8">
        <button onClick={toggleLanguage} className="p-2 rounded-full text-gray-500 hover:bg-gray-200 dark:text-gray-400 dark:hover:bg-slate-700 font-bold text-sm">
            {lang === 'en' ? 'ع' : 'EN'}
        </button>
      </div>

      <div className="w-full max-w-lg bg-background dark:bg-dark-secondary rounded-2xl shadow-xl p-8 relative">
        {onBackToLogin && !onCancel && (
            <button
                onClick={onBackToLogin}
                className="absolute top-6 start-6 flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-md"
            >
                <Icons.ArrowLeft className={`h-4 w-4 me-2 ${lang === 'ar' ? 'transform rotate-180' : ''}`} />
                {t.common.backToLogin}
            </button>
        )}
        <div className="text-center mb-8 pt-8">
            <Icons.User className="mx-auto h-12 w-12 text-primary" />
            <h1 className="text-3xl font-bold text-foreground dark:text-dark-foreground mt-4">
                {onCancel ? t.registration.doctorTitle : t.registration.patientTitle}
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
                {onCancel ? t.registration.doctorSubtitle : t.registration.patientSubtitle}
            </p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.name}</label>
                  <input required type="text" name="name" value={formData.name} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                </div>
                 <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.age}</label>
                  <input required type="number" name="age" value={formData.age} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.weight}</label>
                  <input required type="number" step="0.1" name="weight" value={formData.weight} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.height}</label>
                  <input required type="number" name="height" value={formData.height} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.gender}</label>
                    <select name="gender" onChange={handleChange} value={formData.gender} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary">
                    <option value={Gender.MALE}>{t.form.male}</option>
                    <option value={Gender.FEMALE}>{t.form.female}</option>
                    </select>
                </div>
              </div>
          
           <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.activityLevel}</label>
            <select name="activityLevel" onChange={handleChange} value={formData.activityLevel} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary">
              {translatedActivityOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
            </select>
          </div>
          
          <div className="pt-4 flex items-center space-x-3">
            {onCancel && (
                 <button
                    type="button"
                    onClick={onCancel}
                    className="w-full flex items-center justify-center py-3 px-4 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm text-lg font-medium text-foreground dark:text-dark-foreground bg-white dark:bg-slate-700 hover:bg-gray-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-light transition-colors duration-300"
                >
                    {t.common.cancel}
                </button>
            )}
            <button type="submit" className="w-full flex items-center justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-light transition-colors duration-300">
              {onCancel ? t.registration.addPatientButton : t.registration.createProfileButton}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RegistrationPage;