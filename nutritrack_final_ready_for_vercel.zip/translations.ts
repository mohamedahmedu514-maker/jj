// NutriTrack Health Management System - Created by Anas Bahaa

export type Language = 'en' | 'ar';

export const translations = {
  en: {
    doctorName: "Dr. Anas Bahaa",
    systemName: "NutriTrack Health System",
    login: {
      title: "NutriTrack Health Management System",
      subtitle: "Professional tool for clinicians and patients.",
      systemLogin: "System Login",
      patientLogin: "Patient Login",
      clinicianLogin: "Clinician Login",
    },
    registration: {
      patientTitle: "New Patient Registration",
      patientSubtitle: "Please complete the following fields to create a profile.",
      doctorTitle: "New Patient Registration",
      doctorSubtitle: "Complete the fields to create a new patient profile.",
      createProfileButton: "Create Profile",
      addPatientButton: "Add Patient",
    },
    form: {
      name: "Name",
      age: "Age",
      weight: "Weight (kg)",
      height: "Height (cm)",
      gender: "Gender",
      male: "Male",
      female: "Female",
      activityLevel: "Activity Level",
      waterGoal: "Daily Water Goal (ml)",
      email: "Email",
      subject: "Subject",
      message: "Message",
    },
    activityLevels: {
      sedentary: "Sedentary (little or no exercise)",
      lightly: "Lightly active (light exercise/sports 1-3 days/week)",
      moderate: "Moderately active (moderate exercise/sports 3-5 days/week)",
      very: "Very active (hard exercise/sports 6-7 days a week)",
    },
    header: {
        patient: "Patient",
        myDashboard: "My Dashboard",
        updateWeight: "Update Weight",
        editProfile: "Edit Profile",
        exportPdf: "Export PDF",
        exporting: "Exporting...",
        feedback: "Feedback",
        logout: "Logout",
    },
    bmiCard: {
        title: "Your BMI",
        categories: {
            underweight: { label: "Underweight", suggestion: "Focus on a high-calorie, protein-rich diet to build mass." },
            normal: { label: "Normal weight", suggestion: "Maintain a balanced diet to stay in a healthy range." },
            overweight: { label: "Overweight", suggestion: "Consider a low-carb, calorie-deficit diet to manage weight." },
            obese: { label: "Obese", suggestion: "Adopt a low-carb, high-protein diet with significant calorie restriction." }
        }
    },
    caloriesCard: {
        dailyGoal: "Daily Goal",
        caloriesDay: "Calories/day",
        suggestion: "This is an estimate for maintaining your current weight.",
    },
    waterCard: {
        title: "Water Intake",
        ml: "ml",
        addGlass: "+1 Glass (250ml)",
        addBottle: "+1 Bottle (500ml)",
    },
    appointments: {
        nextAppointment: "Next Appointment",
        noneScheduled: "None Scheduled",
        schedule: "Schedule",
        note: "Note",
        noUpcoming: "No upcoming appointments.",
    },
    progressChart: {
        title: "Your Progress",
        date: "Date",
        weight: "Weight",
        kg: "kg",
        bmi: "BMI",
        empty: {
            title: "Your journey begins!",
            subtitle: "Update your weight to start tracking your progress on the chart.",
        }
    },
    complianceChart: {
        title: "Patient Compliance",
        compliance: "Compliance",
        empty: {
            title: "Compliance data will appear here.",
            subtitle: "More progress updates are needed to track patient diet adherence.",
        }
    },
    dietPlan: {
        title: "Daily Diet Plan",
        kcal: "kcal",
        day: "day",
        edit: "Edit",
        createPlan: "Create Diet Plan",
        noPlan: {
            title: "No Diet Plan Assigned",
            doctor: "Click the button below to create a personalized diet plan for this patient.",
            patient: "Your clinician has not assigned a diet plan yet. Please check back later.",
        },
        filters: {
            all: "All",
            breakfast: "Breakfast",
            lunch: "Lunch",
            dinner: "Dinner",
            snacks: "Snacks",
        },
        noSnacks: "No snacks assigned.",
    },
    updateWeightModal: {
        title: "Update Your Weight",
        description: "Regularly updating your weight helps in tracking your progress accurately.",
        label: "New Weight (kg)",
    },
    editProfileModal: {
        title: "Edit Patient Profile",
    },
    editDietPlanModal: {
        createTitle: "Create Diet Plan",
        editTitle: "Edit Diet Plan",
        mealName: "Meal Name",
        description: "Description",
        snackName: "Snack Name",
        addSnack: "Add Snack",
        summary: "Summary / Doctor's Notes",
        summaryPlaceholder: "Overall dietary advice or instructions for the patient.",
    },
    scheduleModal: {
        title: "Schedule for",
        date: "Date",
        time: "Time",
        notes: "Notes (Optional)",
        notesPlaceholder: "e.g., Follow-up consultation",
        save: "Save Appointment",
    },
    feedbackModal: {
        title: "Contact & Feedback",
        rateService: "Rate our service",
        submit: "Submit Feedback",
        submitted: {
            title: "Thank you!",
            message: "Your feedback has been submitted successfully.",
        }
    },
    doctorDashboard: {
        title: "Patient Management",
        subtitle: "Select a patient to view their dashboard.",
        searchPlaceholder: "Search by patient name...",
        id: "ID",
        lastUpdated: "Last Updated",
        weight: "Weight",
        noPatients: "No patients found.",
        addPatient: "Add Patient",
        upcomingAppointments: "Upcoming Appointments",
        noAppointments: "No upcoming appointments.",
    },
    onboarding: {
        skip: "Skip Tour",
        next: "Next",
        finish: "Finish",
        patient: [
            { title: 'Welcome to Your Dashboard!', content: 'This quick tour will show you how to get the most out of NutriTrack. Let\'s get started.' },
            { title: 'Your Health Snapshot', content: 'Here you\'ll find your key metrics like BMI, calories, and water intake. These update automatically as you track your progress.' },
            { title: 'Upcoming Appointments', content: 'Your clinician will schedule your appointments here. Check this card to see your next clinic visit date and time.' },
            { title: 'Track Your Progress', content: 'The main chart shows your weight and BMI changes over time. Use the "Update Weight" button regularly to keep it accurate.' },
            { title: 'Your Prescribed Diet Plan', content: 'Your doctor will create and update your personalized diet plan here. Check back to see the meals they have assigned for you.' }
        ],
        doctor: [
            { title: 'Welcome, Doctor!', content: 'This quick tour will guide you through the patient management dashboard.' },
            { title: 'Patient Health Snapshot', content: 'At a glance, you can see their key metrics, calorie goals, and progress history. You can also see and schedule their next appointment.' },
            { title: 'Manual Diet Plan Control', content: 'You have full control over the patient\'s diet. Click "Create Plan" or "Edit Plan" to manually enter meals, calorie counts, and notes.' },
            { title: 'Manage and Export', content: 'You can edit patient profiles, update their diet plans, schedule visits, and export their entire report as a PDF for their records.' }
        ]
    },
    common: {
        cancel: "Cancel",
        update: "Update",
        saveChanges: "Save Changes",
        savePlan: "Save Plan",
        backToLogin: "Back to Login",
    }
  },
  ar: {
    doctorName: "د. أنس بهاء",
    systemName: "نظام نيوتري تراك الصحي",
    login: {
      title: "نظام نيوتري تراك لإدارة الصحة",
      subtitle: "أداة احترافية للأطباء والمرضى.",
      systemLogin: "تسجيل دخول النظام",
      patientLogin: "دخول المريض",
      clinicianLogin: "دخول الطبيب",
    },
    registration: {
      patientTitle: "تسجيل مريض جديد",
      patientSubtitle: "يرجى إكمال الحقول التالية لإنشاء ملف تعريف.",
      doctorTitle: "تسجيل مريض جديد",
      doctorSubtitle: "أكمل الحقول لإنشاء ملف مريض جديد.",
      createProfileButton: "إنشاء ملف",
      addPatientButton: "إضافة مريض",
    },
    form: {
      name: "الاسم",
      age: "العمر",
      weight: "الوزن (كجم)",
      height: "الطول (سم)",
      gender: "الجنس",
      male: "ذكر",
      female: "أنثى",
      activityLevel: "مستوى النشاط",
      waterGoal: "هدف شرب الماء اليومي (مل)",
      email: "البريد الإلكتروني",
      subject: "الموضوع",
      message: "الرسالة",
    },
    activityLevels: {
      sedentary: "خامل (قليل أو بدون تمرين)",
      lightly: "نشاط خفيف (تمرين خفيف/رياضة 1-3 أيام/أسبوع)",
      moderate: "نشاط معتدل (تمرين معتدل/رياضة 3-5 أيام/أسبوع)",
      very: "نشيط جدًا (تمرين شاق/رياضة 6-7 أيام/أسبوع)",
    },
    header: {
        patient: "مريض",
        myDashboard: "لوحة التحكم",
        updateWeight: "تحديث الوزن",
        editProfile: "تعديل الملف",
        exportPdf: "تصدير PDF",
        exporting: "جاري التصدير...",
        feedback: "ملاحظات",
        logout: "تسجيل الخروج",
    },
    bmiCard: {
        title: "مؤشر كتلة الجسم",
        categories: {
            underweight: { label: "نقص الوزن", suggestion: "ركز على نظام غذائي عالي السعرات والبروتين لبناء الكتلة." },
            normal: { label: "وزن طبيعي", suggestion: "حافظ على نظام غذائي متوازن للبقاء في نطاق صحي." },
            overweight: { label: "زيادة الوزن", suggestion: "فكر في نظام غذائي منخفض الكربوهيدرات مع عجز في السعرات الحرارية." },
            obese: { label: "سمنة", suggestion: "اعتمد نظامًا غذائيًا منخفض الكربوهيدرات وعالي البروتين مع تقييد كبير للسعرات." }
        }
    },
    caloriesCard: {
        dailyGoal: "الهدف اليومي",
        caloriesDay: "سعرة حرارية/يوم",
        suggestion: "هذا تقدير للحفاظ على وزنك الحالي.",
    },
    waterCard: {
        title: "استهلاك الماء",
        ml: "مل",
        addGlass: "+1 كوب (250مل)",
        addBottle: "+1 زجاجة (500مل)",
    },
    appointments: {
        nextAppointment: "الموعد القادم",
        noneScheduled: "لا يوجد مواعيد",
        schedule: "جدولة",
        note: "ملاحظة",
        noUpcoming: "لا توجد مواعيد قادمة.",
    },
    progressChart: {
        title: "تقدمك",
        date: "التاريخ",
        weight: "الوزن",
        kg: "كجم",
        bmi: "مؤشر كتلة الجسم",
        empty: {
            title: "رحلتك تبدأ!",
            subtitle: "حدّث وزنك لبدء تتبع تقدمك على الرسم البياني.",
        }
    },
    complianceChart: {
        title: "امتثال المريض",
        compliance: "الامتثال",
        empty: {
            title: "ستظهر بيانات الامتثال هنا.",
            subtitle: "هناك حاجة إلى المزيد من تحديثات التقدم لتتبع التزام المريض بالنظام الغذائي.",
        }
    },
    dietPlan: {
        title: "خطة النظام الغذائي اليومية",
        kcal: "سعرة",
        day: "اليوم",
        edit: "تعديل",
        createPlan: "إنشاء خطة",
        noPlan: {
            title: "لم يتم تعيين خطة نظام غذائي",
            doctor: "انقر على الزر أدناه لإنشاء خطة نظام غذائي مخصصة لهذا المريض.",
            patient: "لم يقم طبيبك بتعيين خطة نظام غذائي بعد. يرجى المراجعة لاحقًا.",
        },
        filters: {
            all: "الكل",
            breakfast: "الإفطار",
            lunch: "الغداء",
            dinner: "العشاء",
            snacks: "وجبات خفيفة",
        },
        noSnacks: "لم يتم تعيين وجبات خفيفة.",
    },
    updateWeightModal: {
        title: "تحديث وزنك",
        description: "يساعد تحديث وزنك بانتظام في تتبع تقدمك بدقة.",
        label: "الوزن الجديد (كجم)",
    },
    editProfileModal: {
        title: "تعديل ملف المريض",
    },
    editDietPlanModal: {
        createTitle: "إنشاء خطة نظام غذائي",
        editTitle: "تعديل خطة النظام الغذائي",
        mealName: "اسم الوجبة",
        description: "الوصف",
        snackName: "اسم الوجبة الخفيفة",
        addSnack: "إضافة وجبة خفيفة",
        summary: "ملخص / ملاحظات الطبيب",
        summaryPlaceholder: "نصائح غذائية عامة أو تعليمات للمريض.",
    },
    scheduleModal: {
        title: "جدولة موعد لـ",
        date: "التاريخ",
        time: "الوقت",
        notes: "ملاحظات (اختياري)",
        notesPlaceholder: "مثال: استشارة متابعة",
        save: "حفظ الموعد",
    },
    feedbackModal: {
        title: "الاتصال والملاحظات",
        rateService: "قيّم خدمتنا",
        submit: "إرسال الملاحظات",
        submitted: {
            title: "شكرًا لك!",
            message: "تم إرسال ملاحظاتك بنجاح.",
        }
    },
    doctorDashboard: {
        title: "إدارة المرضى",
        subtitle: "اختر مريضًا لعرض لوحة التحكم الخاصة به.",
        searchPlaceholder: "ابحث باسم المريض...",
        id: "معرف",
        lastUpdated: "آخر تحديث",
        weight: "الوزن",
        noPatients: "لم يتم العثور على مرضى.",
        addPatient: "إضافة مريض",
        upcomingAppointments: "المواعيد القادمة",
        noAppointments: "لا توجد مواعيد قادمة.",
    },
    onboarding: {
        skip: "تخطي الجولة",
        next: "التالي",
        finish: "إنهاء",
        patient: [
            { title: 'أهلاً بك في لوحة التحكم!', content: 'ستوضح لك هذه الجولة السريعة كيفية تحقيق أقصى استفادة من نيوتري تراك. هيا بنا نبدأ.' },
            { title: 'لمحة عن صحتك', content: 'ستجد هنا مقاييسك الرئيسية مثل مؤشر كتلة الجسم والسعرات الحرارية واستهلاك الماء. يتم تحديثها تلقائيًا أثناء تتبع تقدمك.' },
            { title: 'المواعيد القادمة', content: 'سيقوم طبيبك بجدولة مواعيدك هنا. تحقق من هذه البطاقة لمعرفة تاريخ ووقت زيارتك القادمة للعيادة.' },
            { title: 'تتبع تقدمك', content: 'يعرض الرسم البياني الرئيسي تغيرات وزنك ومؤشر كتلة الجسم بمرور الوقت. استخدم زر "تحديث الوزن" بانتظام للحفاظ على دقته.' },
            { title: 'خطتك الغذائية الموصوفة', content: 'سيقوم طبيبك بإنشاء وتحديث خطتك الغذائية المخصصة هنا. تحقق مرة أخرى لرؤية الوجبات التي حددها لك.' }
        ],
        doctor: [
            { title: 'أهلاً بك يا دكتور!', content: 'ستوجهك هذه الجولة السريعة خلال لوحة تحكم إدارة المرضى.' },
            { title: 'لمحة عن صحة المريض', content: 'بلمحة واحدة، يمكنك رؤية مقاييسهم الرئيسية وأهداف السعرات الحرارية وسجل التقدم. يمكنك أيضًا رؤية وجدولة موعدهم التالي.' },
            { title: 'التحكم اليدوي في الخطة الغذائية', content: 'لديك سيطرة كاملة على نظام المريض الغذائي. انقر على "إنشاء خطة" أو "تعديل الخطة" لإدخال الوجبات وعدد السعرات الحرارية والملاحظات يدويًا.' },
            { title: 'الإدارة والتصدير', content: 'يمكنك تعديل ملفات المرضى، وتحديث خططهم الغذائية، وجدولة الزيارات، وتصدير تقريرهم بالكامل كملف PDF لسجلاتهم.' }
        ]
    },
    common: {
        cancel: "إلغاء",
        update: "تحديث",
        saveChanges: "حفظ التغييرات",
        savePlan: "حفظ الخطة",
        backToLogin: "العودة لتسجيل الدخول",
    }
  }
};