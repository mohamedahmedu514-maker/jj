// NutriTrack Health Management System - Created by Anas Bahaa
import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import { UserData, UserRole, ProgressEntry } from './types';
import useLocalStorage from './hooks/useLocalStorage';
import { db, PatientProfile } from './db';
import { calculateBMI } from './utils/calculations';
import LoginPage from './pages/LoginPage';
import RegistrationPage from './pages/RegistrationPage';
import PatientDashboardPage from './pages/PatientDashboardPage';
import DoctorDashboardPage from './pages/DoctorDashboardPage';
import { Language } from './translations';

type View = 'login' | 'patient-form' | 'doctor-selector' | 'dashboard' | 'add-patient-form';
type Theme = 'light' | 'dark';

function App() {
  const [userRole, setUserRole] = useLocalStorage<UserRole | null>('userRole', null);
  const [view, setView] = useState<View>('login');
  const [theme, setTheme] = useLocalStorage<Theme>('theme', 'light');
  const [lang, setLang] = useLocalStorage<Language>('language', 'en');

  // Onboarding state: store completion status for each role
  const [onboardingStatus, setOnboardingStatus] = useLocalStorage<{ [key in UserRole]?: boolean }>('onboardingStatus', {});
  const [showOnboarding, setShowOnboarding] = useState(false);

  // Doctor state
  const [patients, setPatients] = useLocalStorage<PatientProfile[]>('patients', db);
  const [selectedPatient, setSelectedPatient] = useState<PatientProfile | null>(null);

  // Patient state
  const [patientProfile, setPatientProfile] = useLocalStorage<PatientProfile | null>('patientProfile', null);

  // Effect to apply the theme class and language direction to the root element
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    root.classList.add(theme);
    root.dir = lang === 'ar' ? 'rtl' : 'ltr';
    root.lang = lang;
  }, [theme, lang]);

  useEffect(() => {
    if (userRole) {
      if (userRole === UserRole.DOCTOR) {
        setView(selectedPatient ? 'dashboard' : 'doctor-selector');
      } else { // PATIENT
        setView(patientProfile ? 'dashboard' : 'patient-form');
      }
    } else {
      setView('login');
      setSelectedPatient(null);
    }
  }, [userRole, patientProfile, selectedPatient]);

  // Effect to trigger the onboarding guide
  useEffect(() => {
    if (view === 'dashboard' && userRole && !onboardingStatus[userRole]) {
      setShowOnboarding(true);
    } else {
      setShowOnboarding(false);
    }
  }, [view, userRole, onboardingStatus]);

  const handleLogin = (role: UserRole) => {
    setUserRole(role);
  };
  
  const handleLogout = () => {
    setUserRole(null);
    setSelectedPatient(null);
    setShowOnboarding(false); // Reset on logout
  };

  const handlePatientSubmit = (data: Omit<UserData, 'id' | 'weight'> & { weight: number }) => {
    const newPatientData: UserData = {
      ...data,
      id: Date.now(),
    };
    const newProfile: PatientProfile = {
      data: newPatientData,
      progressHistory: [{
        date: new Date().toISOString(),
        weight: data.weight,
        bmi: calculateBMI(data.weight, data.height),
      }],
      dietPlan: null,
      appointments: [],
    };
    setPatientProfile(newProfile);
  };
  
  const handleAddPatientSubmit = (data: Omit<UserData, 'id' | 'weight'> & { weight: number }) => {
    const newPatientData: UserData = {
      ...data,
      id: Date.now(),
    };
    const newProfile: PatientProfile = {
      data: newPatientData,
      progressHistory: [{
        date: new Date().toISOString(),
        weight: data.weight,
        bmi: calculateBMI(data.weight, data.height),
      }],
      dietPlan: null,
      appointments: [],
    };
    setPatients(prev => [...prev, newProfile]);
    setSelectedPatient(newProfile); // select the new patient
    setView('dashboard');
  };

  const handleSelectPatient = (patient: PatientProfile) => {
    setSelectedPatient(patient);
  };
  
  const handleUpdatePatientProfile = (updatedProfile: PatientProfile) => {
      if (userRole === UserRole.DOCTOR) {
          setPatients(prev => prev.map(p => p.data.id === updatedProfile.data.id ? updatedProfile : p));
          setSelectedPatient(updatedProfile);
      } else {
          setPatientProfile(updatedProfile);
      }
  }
  
  const handleOnboardingComplete = () => {
      if (userRole) {
          setOnboardingStatus(prev => ({...prev, [userRole]: true}));
      }
      setShowOnboarding(false);
  }

  const currentProfile = userRole === UserRole.DOCTOR ? selectedPatient : patientProfile;

  // This effect handles invalid dashboard states by logging the user out, preventing render errors.
  useEffect(() => {
    if (view === 'dashboard' && (!currentProfile || !userRole)) {
        handleLogout();
    }
  }, [view, currentProfile, userRole]);

  const renderContent = () => {
    switch (view) {
      case 'login':
        return <LoginPage onLogin={handleLogin} lang={lang} setLang={setLang} />;
      case 'patient-form':
        return <RegistrationPage onSubmit={handlePatientSubmit} onBackToLogin={handleLogout} lang={lang} setLang={setLang} />;
      case 'doctor-selector':
        return (
          <DoctorDashboardPage
            patients={patients}
            onSelectPatient={handleSelectPatient}
            onAddPatient={() => setView('add-patient-form')}
            onLogout={handleLogout}
            lang={lang}
            setLang={setLang}
          />
        );
      case 'add-patient-form':
          return (
            <RegistrationPage
                onSubmit={handleAddPatientSubmit}
                onCancel={() => setView('doctor-selector')}
                onBackToLogin={handleLogout}
                lang={lang}
                setLang={setLang}
            />
          );
      case 'dashboard':
        // If the state is invalid, the useEffect above will trigger a re-render.
        // Return null to prevent rendering with bad props while the state updates.
        if (!currentProfile || !userRole) {
            return null;
        }
        return (
          <PatientDashboardPage
            key={currentProfile.data.id} // Re-mounts dashboard when patient changes
            patientProfile={currentProfile}
            userRole={userRole}
            onUpdateProfile={handleUpdatePatientProfile}
            onLogout={handleLogout}
            onBackToPatients={userRole === UserRole.DOCTOR ? () => setSelectedPatient(null) : undefined}
            onBack={userRole === UserRole.PATIENT ? handleLogout : undefined}
            showOnboarding={showOnboarding}
            onOnboardingComplete={handleOnboardingComplete}
            theme={theme}
            setTheme={setTheme}
            lang={lang}
            setLang={setLang}
          />
        );
      default:
        return <LoginPage onLogin={handleLogin} lang={lang} setLang={setLang} />;
    }
  };

  return (
    <main className="bg-secondary dark:bg-dark-background text-foreground dark:text-dark-foreground font-sans">
      <AnimatePresence mode="wait">
        {renderContent()}
      </AnimatePresence>
    </main>
  );
}

export default App;