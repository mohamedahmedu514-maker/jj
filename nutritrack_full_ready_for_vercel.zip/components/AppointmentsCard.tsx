// NutriTrack Health Management System - Created by Anas Bahaa
import React from 'react';
import { motion } from 'framer-motion';
import { Appointment, UserRole } from '../types';
import Icons from './Icons';
import { translations, Language } from '../translations';

interface AppointmentsCardProps {
  appointments: Appointment[];
  userRole: UserRole;
  onScheduleNew: () => void;
  lang: Language;
}

const AppointmentsCard: React.FC<AppointmentsCardProps> = ({ appointments, userRole, onScheduleNew, lang }) => {
  const t = translations[lang];
  const upcomingAppointment = appointments
    .filter(app => new Date(app.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())[0];

  const formatDate = (date: Date) => {
    return date.toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US', { weekday: 'long', month: 'short', day: 'numeric' });
  };
  
  const formatTime = (date: Date) => {
      return date.toLocaleTimeString(lang === 'ar' ? 'ar-EG' : 'en-US', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-background dark:bg-dark-secondary p-6 rounded-2xl shadow-md"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
            <div className="bg-primary/10 text-primary p-3 rounded-full me-4">
                <Icons.CalendarDays className="h-6 w-6" />
            </div>
            <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{t.appointments.nextAppointment}</p>
                <p className="text-xl font-bold text-foreground dark:text-dark-foreground">
                    {upcomingAppointment ? formatDate(new Date(upcomingAppointment.date)) : t.appointments.noneScheduled}
                </p>
            </div>
        </div>
         {userRole === UserRole.DOCTOR && (
            <button
                onClick={onScheduleNew}
                className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-md"
            >
                <Icons.Plus className="h-4 w-4 sm:me-2" />
                <span className="hidden sm:inline">{t.appointments.schedule}</span>
            </button>
         )}
      </div>

      {upcomingAppointment ? (
        <div className="text-center bg-primary/5 dark:bg-primary/10 p-3 rounded-lg">
            <p className="text-lg font-semibold text-primary">{formatTime(new Date(upcomingAppointment.date))}</p>
            {upcomingAppointment.notes && <p className="text-xs text-primary/80 mt-1 italic">{t.appointments.note}: "{upcomingAppointment.notes}"</p>}
        </div>
      ) : (
        <div className="text-center text-gray-500 dark:text-gray-400 py-3">
             <p className="text-sm">{t.appointments.noUpcoming}</p>
        </div>
      )}
    </motion.div>
  );
};

export default AppointmentsCard;