// NutriTrack Health Management System - Created by Anas Bahaa
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icons from './Icons';
import { UserData } from '../types';
import { translations, Language } from '../translations';


interface FeedbackModalProps {
  onClose: () => void;
  userData: UserData;
  lang: Language;
}

const StarRating: React.FC<{ rating: number; setRating: (rating: number) => void }> = ({ rating, setRating }) => {
    return (
        <div className="flex items-center space-x-1">
            {[1, 2, 3, 4, 5].map((star) => (
                <motion.button
                    type="button"
                    key={star}
                    onClick={() => setRating(star)}
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-1 focus:outline-none"
                >
                    <Icons.Star
                        className={`h-6 w-6 transition-colors ${
                            star <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-400'
                        }`}
                    />
                </motion.button>
            ))}
        </div>
    );
};


const FeedbackModal: React.FC<FeedbackModalProps> = ({ onClose, userData, lang }) => {
  const [formData, setFormData] = useState({
    name: userData.name,
    email: `${userData.name.toLowerCase().replace(/\s/g, '.')}@example.com`, // dummy email
    subject: '',
    message: '',
  });
  const [rating, setRating] = useState(0);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const t = translations[lang];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Feedback Submitted:", { ...formData, rating });
    setIsSubmitted(true);
    setTimeout(() => {
        onClose();
    }, 2500); // Close modal after 2.5 seconds
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: -20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: -20 }}
        className="bg-background dark:bg-dark-secondary rounded-2xl shadow-xl w-full max-w-md p-6"
        onClick={(e) => e.stopPropagation()}
      >
        {isSubmitted ? (
             <div className="text-center py-8">
                <motion.div initial={{scale:0}} animate={{scale:1}} transition={{type: 'spring', stiffness: 260, damping: 20}}>
                    <Icons.ClipboardCheck className="h-16 w-16 text-primary mx-auto"/>
                </motion.div>
                <h2 className="text-xl font-bold text-foreground dark:text-dark-foreground mt-4">{t.feedbackModal.submitted.title}</h2>
                <p className="text-gray-600 dark:text-gray-400 mt-2">{t.feedbackModal.submitted.message}</p>
            </div>
        ) : (
        <>
            <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-foreground dark:text-dark-foreground">{t.feedbackModal.title}</h2>
            <button onClick={onClose} className="p-1 rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-slate-700">
                <Icons.X className="h-5 w-5" />
            </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.name}</label>
                        <input required type="text" name="name" value={formData.name} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.email}</label>
                        <input required type="email" name="email" value={formData.email} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                    </div>
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.subject}</label>
                    <input required type="text" name="subject" value={formData.subject} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.form.message}</label>
                    <textarea required name="message" rows={4} value={formData.message} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t.feedbackModal.rateService}</label>
                    <StarRating rating={rating} setRating={setRating} />
                </div>

                <div className="mt-6 flex justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-slate-700">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-md">
                    {t.common.cancel}
                    </button>
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md">
                    {t.feedbackModal.submit}
                    </button>
                </div>
            </form>
        </>
        )}
      </motion.div>
    </motion.div>
  );
};

export default FeedbackModal;