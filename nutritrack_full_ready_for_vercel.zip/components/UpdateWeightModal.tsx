// NutriTrack Health Management System - Created by Anas Bahaa
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icons from './Icons';
import { translations, Language } from '../translations';

interface UpdateWeightModalProps {
  onClose: () => void;
  onUpdate: (newWeight: number) => void;
  currentWeight: number;
  lang: Language;
}

const UpdateWeightModal: React.FC<UpdateWeightModalProps> = ({ onClose, onUpdate, currentWeight, lang }) => {
  const [newWeight, setNewWeight] = useState(currentWeight);
  const t = translations[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newWeight > 0) {
      onUpdate(newWeight);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: -20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: -20 }}
        className="bg-background dark:bg-dark-secondary rounded-2xl shadow-xl w-full max-w-sm p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-foreground dark:text-dark-foreground">{t.updateWeightModal.title}</h2>
          <button onClick={onClose} className="p-1 rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-slate-700">
            <Icons.X className="h-5 w-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            {t.updateWeightModal.description}
          </p>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.updateWeightModal.label}</label>
            <input
              type="number"
              step="0.1"
              value={newWeight}
              onChange={(e) => setNewWeight(parseFloat(e.target.value))}
              className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
              autoFocus
            />
          </div>
          <div className="mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-md"
            >
              {t.common.cancel}
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md"
            >
              {t.common.update}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default UpdateWeightModal;