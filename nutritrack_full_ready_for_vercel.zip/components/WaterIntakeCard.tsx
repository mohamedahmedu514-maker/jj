// NutriTrack Health Management System - Created by Anas Bahaa
import React from 'react';
import { motion } from 'framer-motion';
import Icons from './Icons';
import { translations, Language } from '../translations';

interface WaterIntakeCardProps {
  currentIntake: number;
  goal: number;
  onAddWater: (amount: number) => void;
  lang: Language;
}

const WaterIntakeCard: React.FC<WaterIntakeCardProps> = ({ currentIntake, goal, onAddWater, lang }) => {
  const percentage = goal > 0 ? Math.min((currentIntake / goal) * 100, 100) : 0;
  const t = translations[lang];

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-background dark:bg-dark-secondary p-6 rounded-2xl shadow-md"
    >
      <div className="flex items-center mb-4">
        <div className="bg-primary/10 text-primary p-3 rounded-full me-4">
          <Icons.GlassWater className="h-6 w-6" />
        </div>
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">{t.waterCard.title}</p>
          <p className="text-3xl font-bold text-foreground dark:text-dark-foreground">
            {currentIntake}<span className="text-lg text-gray-400">/{goal} {t.waterCard.ml}</span>
          </p>
        </div>
      </div>
      
      <div className="relative h-24 w-full mb-4">
        <div className="absolute inset-0 flex items-center justify-center">
            <p className="text-2xl font-bold text-primary">{Math.round(percentage)}%</p>
        </div>
        <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
            <circle cx="50" cy="50" r="45" strokeWidth="8" className="stroke-current text-gray-200 dark:text-slate-700" fill="transparent" />
            <motion.circle
                cx="50"
                cy="50"
                r="45"
                strokeWidth="8"
                strokeDasharray="282.7"
                strokeDashoffset={282.7 - (percentage / 100) * 282.7}
                strokeLinecap="round"
                className="stroke-current text-primary"
                fill="transparent"
                initial={{ strokeDashoffset: 282.7 }}
                animate={{ strokeDashoffset: 282.7 - (percentage / 100) * 282.7 }}
                transition={{ duration: 1, ease: "circOut" }}
            />
        </svg>
      </div>

      <div className="grid grid-cols-2 gap-2 text-sm">
        <button 
          onClick={() => onAddWater(250)}
          className="py-2 px-3 bg-primary/10 hover:bg-primary/20 text-primary-dark dark:text-primary-light font-semibold rounded-md transition-colors"
        >
          {t.waterCard.addGlass}
        </button>
        <button 
          onClick={() => onAddWater(500)}
          className="py-2 px-3 bg-primary/10 hover:bg-primary/20 text-primary-dark dark:text-primary-light font-semibold rounded-md transition-colors"
        >
          {t.waterCard.addBottle}
        </button>
      </div>
    </motion.div>
  );
};

export default WaterIntakeCard;