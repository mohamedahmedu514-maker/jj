// NutriTrack Health Management System - Created by Anas Bahaa
import React from 'react';
import { motion } from 'framer-motion';
import { UserRole } from '../types';
import Icons from '../components/Icons';
import { translations, Language } from '../translations';

interface LoginPageProps {
  onLogin: (role: UserRole) => void;
  lang: Language;
  setLang: (lang: Language) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin, lang, setLang }) => {
  const t = translations[lang];

  const toggleLanguage = () => {
    setLang(lang === 'en' ? 'ar' : 'en');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-secondary dark:bg-dark-background p-4 relative">
      <div className="absolute top-8 start-8 text-start">
        <h2 className="text-xl font-bold text-primary">{t.doctorName}</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">{t.systemName}</p>
      </div>
       <div className="absolute top-8 end-8">
        <button onClick={toggleLanguage} className="p-2 rounded-full text-gray-500 hover:bg-gray-200 dark:text-gray-400 dark:hover:bg-slate-700 font-bold text-sm">
            {lang === 'en' ? 'ع' : 'EN'}
        </button>
      </div>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-background dark:bg-dark-secondary rounded-2xl shadow-xl p-8 text-center"
      >
        <Icons.HeartPulse className="mx-auto h-16 w-16 text-primary" />
        <h1 className="text-3xl font-bold text-foreground dark:text-dark-foreground mt-4">{t.login.title}</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2 mb-8">{t.login.subtitle}</p>
        
        <h2 className="text-xl font-semibold text-foreground dark:text-dark-foreground mb-4">{t.login.systemLogin}</h2>
        <div className="space-y-4">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onLogin(UserRole.PATIENT)}
            className="w-full flex items-center justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-light transition-colors duration-300"
          >
            <Icons.User className="h-5 w-5 me-3" />
            {t.login.patientLogin}
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onLogin(UserRole.DOCTOR)}
            className="w-full flex items-center justify-center py-3 px-4 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm text-lg font-medium text-foreground dark:text-dark-foreground bg-white dark:bg-slate-700 hover:bg-gray-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-light transition-colors duration-300"
          >
            <Icons.BookUser className="h-5 w-5 me-3" />
            {t.login.clinicianLogin}
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;