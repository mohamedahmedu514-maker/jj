// NutriTrack Health Management System - Created by Anas Bahaa
// FIX: Removed self-referencing import and invalid characters from the top of the file to resolve declaration conflicts.
export enum Gender {
  MALE = 'male',
  FEMALE = 'female',
}

export enum ActivityLevel {
  SEDENTARY = 'sedentary',
  LIGHTLY_ACTIVE = 'lightly_active',
  MODERATE = 'moderate',
  VERY_ACTIVE = 'very_active',
}

export enum UserRole {
  PATIENT = 'patient',
  DOCTOR = 'doctor',
}

export interface UserData {
  id: number;
  name: string;
  age: number;
  gender: Gender;
  height: number;
  weight: number;
  activityLevel: ActivityLevel;
  waterGoal: number; // in ml
}

export interface ProgressEntry {
  date: string;
  weight: number;
  bmi: number;
  compliance?: number;
  waterIntake?: number; // in ml
}

export interface Meal {
    name: string;
    description: string;
    calories: number;
}

export interface DietPlan {
    breakfast: Meal;
    lunch: Meal;
    dinner: Meal;
    snacks: Meal[];
    summary: string;
}

export interface DietPreferences {
    allergies: string;
    dietaryRestrictions: string;
    cuisinePreferences: string;
    dislikes: string;
}

export interface Appointment {
  id: number;
  date: string; // ISO string format
  notes?: string;
}
