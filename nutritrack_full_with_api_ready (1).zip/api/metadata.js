  const metadata = {
  "name": "Copy of NutriTrack",
  "description": "A smart nutrition tracking system that calculates BMI, suggests personalized diet plans using AI, and tracks your progress with visual charts.",
  "requestFramePermissions": []
};

  module.exports = (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.status(200).send(metadata);
  };
