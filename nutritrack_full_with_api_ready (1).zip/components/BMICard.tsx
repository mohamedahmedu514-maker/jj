// NutriTrack Health Management System - Created by Anas Bahaa
import React from 'react';
import { motion } from 'framer-motion';
import Icons from './Icons';
import { translations, Language } from '../translations';

interface BMICardProps {
  bmi: number;
  category: {
    label: string;
    color: string;
    suggestion: string;
  };
  lang: Language;
}

const BMICard: React.FC<BMICardProps> = ({ bmi, category, lang }) => {
  const t = translations[lang];
  
  // A simple mapping for category labels
  const categoryKeyMap: {[key: string]: 'underweight' | 'normal' | 'overweight' | 'obese'} = {
      'Underweight': 'underweight',
      'Normal weight': 'normal',
      'Overweight': 'overweight',
      'Obese': 'obese',
  };

  const categoryKey = categoryKeyMap[category.label] || 'obese';

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-background dark:bg-dark-secondary p-6 rounded-2xl shadow-md"
    >
      <div className="flex items-center mb-4">
        <div className="bg-primary/10 text-primary p-3 rounded-full me-4">
          <Icons.HeartPulse className="h-6 w-6" />
        </div>
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">{t.bmiCard.title}</p>
          <p className="text-3xl font-bold text-foreground dark:text-dark-foreground">{bmi}</p>
        </div>
      </div>
      <p className={`text-lg font-semibold ${category.color}`}>{t.bmiCard.categories[categoryKey].label}</p>
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{t.bmiCard.categories[categoryKey].suggestion}</p>
    </motion.div>
  );
};

export default BMICard;