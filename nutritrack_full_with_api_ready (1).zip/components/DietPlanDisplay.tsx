// NutriTrack Health Management System - Created by Anas Bahaa
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DietPlan, Meal, UserRole } from '../types';
import Icons from './Icons';
import { translations, Language } from '../translations';

interface DietPlanDisplayProps {
  plan: DietPlan | null;
  userRole: UserRole;
  onEdit: () => void;
  lang: Language;
}

const AccordionItem: React.FC<{ icon: React.ElementType, title: string, meal: Meal | undefined, children?: React.ReactNode, lang: Language }> = ({ icon: Icon, title, meal, children, lang }) => {
    const [isOpen, setIsOpen] = useState(false);
    const hasContent = meal || (children && React.Children.count(children) > 0);

    return (
        <div className="bg-background dark:bg-dark-secondary rounded-xl border border-gray-200 dark:border-slate-700 overflow-hidden">
            <button
                onClick={() => hasContent && setIsOpen(!isOpen)}
                className={`w-full flex items-center justify-between p-4 ${!hasContent ? 'cursor-not-allowed opacity-60' : ''}`}
            >
                <div className="flex items-center">
                    <Icon className="h-5 w-5 text-primary me-3" />
                    <h4 className="font-bold text-lg text-foreground dark:text-dark-foreground">{title}</h4>
                </div>
                {hasContent && (
                    <motion.div animate={{ rotate: isOpen ? 90 : 0 }}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`${lang === 'ar' ? 'transform -scale-x-100' : ''}`}><polyline points="9 18 15 12 9 6"/></svg>
                    </motion.div>
                )}
            </button>
            <AnimatePresence>
            {isOpen && hasContent && (
                 <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: 'easeInOut' }}
                    className="overflow-hidden"
                 >
                    <div className="p-4 border-t border-gray-200 dark:border-slate-700">
                        {meal && (
                            <div>
                                <p className="font-semibold text-foreground dark:text-dark-foreground">{meal.name}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">{meal.description}</p>
                                <p className="text-sm font-medium text-primary">{meal.calories} {translations[lang].dietPlan.kcal}</p>
                            </div>
                        )}
                        {children}
                    </div>
                </motion.div>
            )}
            </AnimatePresence>
        </div>
    );
};

const DietPlanDisplay: React.FC<DietPlanDisplayProps> = ({ plan, userRole, onEdit, lang }) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'breakfast' | 'lunch' | 'dinner' | 'snacks'>('all');
  const t = translations[lang];

  const filters = [
    { label: t.dietPlan.filters.all, value: 'all' as const },
    { label: t.dietPlan.filters.breakfast, value: 'breakfast' as const },
    { label: t.dietPlan.filters.lunch, value: 'lunch' as const },
    { label: t.dietPlan.filters.dinner, value: 'dinner' as const },
    { label: t.dietPlan.filters.snacks, value: 'snacks' as const },
  ];

  const renderContent = () => {
    if (!plan) {
      return (
        <div className="text-center p-6 flex flex-col items-center justify-center h-full">
          <Icons.Salad className="h-16 w-16 text-primary mb-4" />
          <h3 className="text-xl font-bold text-foreground dark:text-dark-foreground">{t.dietPlan.noPlan.title}</h3>
          {userRole === UserRole.DOCTOR ? (
            <>
                <p className="text-gray-500 dark:text-gray-400 mt-2 mb-4">{t.dietPlan.noPlan.doctor}</p>
                <button
                    onClick={onEdit}
                    className="flex items-center justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-md font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-light transition-colors duration-300"
                >
                    <Icons.Plus className="h-5 w-5 me-2" />
                    {t.dietPlan.createPlan}
                </button>
            </>
          ) : (
            <p className="text-gray-500 dark:text-gray-400 mt-2 mb-4">{t.dietPlan.noPlan.patient}</p>
          )}
        </div>
      );
    }

    const { breakfast, lunch, dinner, snacks, summary } = plan;
    const totalCalories = (breakfast?.calories || 0) + (lunch?.calories || 0) + (dinner?.calories || 0) + snacks.reduce((sum, s) => sum + s.calories, 0);

    return (
      <div className="p-4 sm:p-6">
        <div className="flex justify-between items-start mb-4">
            <div>
                <div className="flex items-center mb-1">
                    <Icons.ClipboardCheck className="h-6 w-6 text-primary me-3" />
                    <h3 className="text-xl font-bold text-foreground dark:text-dark-foreground">{t.dietPlan.title}</h3>
                </div>
                <p className="text-primary font-bold">{totalCalories} {t.dietPlan.kcal} / {t.dietPlan.day}</p>
            </div>
            {userRole === UserRole.DOCTOR && (
                <button onClick={onEdit} className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-md">
                    <Icons.RefreshCw className="h-4 w-4 sm:me-2" />
                    <span className="hidden sm:inline">{t.dietPlan.edit}</span>
                </button>
            )}
        </div>
         {summary && (
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-6 italic border-s-4 border-primary/50 ps-4 py-2 bg-primary/5 dark:bg-primary/10">
                {summary}
            </p>
         )}

        <div className="flex flex-wrap items-center gap-2 mb-4">
            {filters.map((filter) => (
                <button
                    key={filter.value}
                    onClick={() => setActiveFilter(filter.value)}
                    className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                        activeFilter === filter.value
                        ? 'bg-primary text-white shadow'
                        : 'bg-gray-200 dark:bg-slate-700 text-foreground dark:text-dark-foreground hover:bg-gray-300 dark:hover:bg-slate-600'
                    }`}
                >
                    {filter.label}
                </button>
            ))}
        </div>

        <div className="space-y-3">
             <AnimatePresence>
                {(activeFilter === 'all' || activeFilter === 'breakfast') && (
                    <motion.div layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} key="breakfast">
                        <AccordionItem icon={Icons.Apple} title={t.dietPlan.filters.breakfast} meal={breakfast} lang={lang} />
                    </motion.div>
                )}
                {(activeFilter === 'all' || activeFilter === 'lunch') && (
                    <motion.div layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} key="lunch">
                        <AccordionItem icon={Icons.Sandwich} title={t.dietPlan.filters.lunch} meal={lunch} lang={lang} />
                    </motion.div>
                )}
                {(activeFilter === 'all' || activeFilter === 'dinner') && (
                    <motion.div layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} key="dinner">
                         <AccordionItem icon={Icons.Beef} title={t.dietPlan.filters.dinner} meal={dinner} lang={lang} />
                    </motion.div>
                )}
                {(activeFilter === 'all' || activeFilter === 'snacks') && (
                    <motion.div layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} key="snacks">
                        <AccordionItem icon={Icons.Star} title={t.dietPlan.filters.snacks} lang={lang}>
                            {snacks && snacks.length > 0 ? (
                                <div className="grid grid-cols-1 gap-2">
                                    {snacks.map((snack, index) => (
                                        <div key={index} className="p-2 rounded-lg bg-gray-50 dark:bg-slate-800">
                                            <p className="font-semibold text-foreground dark:text-dark-foreground">{snack.name}</p>
                                            <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{snack.description}</p>
                                            <p className="text-xs font-medium text-primary">{snack.calories} {t.dietPlan.kcal}</p>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                 <p className="text-sm text-gray-400 italic">{t.dietPlan.noSnacks}</p>
                            )}
                        </AccordionItem>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
      </div>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-background dark:bg-dark-secondary rounded-2xl shadow-md"
    >
        {renderContent()}
    </motion.div>
  );
};

export default DietPlanDisplay;