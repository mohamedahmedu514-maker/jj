// NutriTrack Health Management System - Created by Anas Bahaa
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icons from './Icons';
import { DietPlan, Meal } from '../types';
import { translations, Language } from '../translations';

interface EditDietPlanModalProps {
  onClose: () => void;
  onSave: (newPlan: DietPlan) => void;
  currentPlan: DietPlan | null;
  lang: Language;
}

const emptyMeal: Meal = { name: '', description: '', calories: 0 };
const emptyPlan: DietPlan = {
  breakfast: emptyMeal,
  lunch: emptyMeal,
  dinner: emptyMeal,
  snacks: [{...emptyMeal}],
  summary: ''
};

const MealInput: React.FC<{
    meal: Meal;
    title: string;
    onUpdate: (meal: Meal) => void;
    lang: Language;
}> = ({ meal, title, onUpdate, lang }) => {
    const t = translations[lang];
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        onUpdate({ ...meal, [name]: name === 'calories' ? Number(value) : value });
    };

    return (
        <div className="space-y-2 p-3 bg-gray-50 dark:bg-slate-800 rounded-lg">
            <h4 className="font-semibold text-foreground dark:text-dark-foreground">{title}</h4>
            <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                <input required type="text" name="name" value={meal.name} onChange={handleChange} placeholder={t.editDietPlanModal.mealName} className="sm:col-span-2 mt-1 block w-full px-2 py-1 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm text-sm" />
                <input required type="text" name="description" value={meal.description} onChange={handleChange} placeholder={t.editDietPlanModal.description} className="sm:col-span-2 mt-1 block w-full px-2 py-1 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm text-sm" />
                <input required type="number" name="calories" value={meal.calories} onChange={handleChange} placeholder={t.dietPlan.kcal} className="sm:col-span-1 mt-1 block w-full px-2 py-1 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm text-sm" />
            </div>
        </div>
    );
};


const EditDietPlanModal: React.FC<EditDietPlanModalProps> = ({ onClose, onSave, currentPlan, lang }) => {
  const [plan, setPlan] = useState<DietPlan>(currentPlan || emptyPlan);
  const t = translations[lang];
  
  const handleMealChange = (category: 'breakfast' | 'lunch' | 'dinner', meal: Meal) => {
    setPlan(prev => ({ ...prev, [category]: meal }));
  };

  const handleSnackChange = (index: number, snack: Meal) => {
    const newSnacks = [...plan.snacks];
    newSnacks[index] = snack;
    setPlan(prev => ({...prev, snacks: newSnacks}));
  };
  
  const addSnack = () => {
      setPlan(prev => ({...prev, snacks: [...prev.snacks, emptyMeal]}));
  }

  const removeSnack = (index: number) => {
      if(plan.snacks.length > 1) {
          setPlan(prev => ({...prev, snacks: prev.snacks.filter((_, i) => i !== index)}));
      }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(plan);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: -20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: -20 }}
        className="bg-background dark:bg-dark-secondary rounded-2xl shadow-xl w-full max-w-2xl p-6 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6 flex-shrink-0">
          <h2 className="text-xl font-bold text-foreground dark:text-dark-foreground">
            {currentPlan ? t.editDietPlanModal.editTitle : t.editDietPlanModal.createTitle}
          </h2>
          <button onClick={onClose} className="p-1 rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-slate-700">
            <Icons.X className="h-5 w-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4 flex-grow overflow-y-auto pr-2">
            <MealInput meal={plan.breakfast} title={t.dietPlan.filters.breakfast} onUpdate={(meal) => handleMealChange('breakfast', meal)} lang={lang} />
            <MealInput meal={plan.lunch} title={t.dietPlan.filters.lunch} onUpdate={(meal) => handleMealChange('lunch', meal)} lang={lang} />
            <MealInput meal={plan.dinner} title={t.dietPlan.filters.dinner} onUpdate={(meal) => handleMealChange('dinner', meal)} lang={lang} />

            <div className="space-y-2 p-3 bg-gray-50 dark:bg-slate-800 rounded-lg">
                <div className="flex justify-between items-center">
                    <h4 className="font-semibold text-foreground dark:text-dark-foreground">{t.dietPlan.filters.snacks}</h4>
                    <button type="button" onClick={addSnack} className="text-xs font-medium text-primary hover:underline flex items-center">
                        <Icons.Plus className="h-3 w-3 me-1"/> {t.editDietPlanModal.addSnack}
                    </button>
                </div>
                {plan.snacks.map((snack, index) => (
                     <div key={index} className="grid grid-cols-1 sm:grid-cols-6 gap-2 items-center">
                        <input required type="text" name="name" value={snack.name} onChange={(e) => handleSnackChange(index, {...snack, name: e.target.value})} placeholder={t.editDietPlanModal.snackName} className="sm:col-span-2 mt-1 block w-full px-2 py-1 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm text-sm" />
                        <input required type="text" name="description" value={snack.description} onChange={(e) => handleSnackChange(index, {...snack, description: e.target.value})} placeholder={t.editDietPlanModal.description} className="sm:col-span-2 mt-1 block w-full px-2 py-1 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm text-sm" />
                        <input required type="number" name="calories" value={snack.calories} onChange={(e) => handleSnackChange(index, {...snack, calories: Number(e.target.value)})} placeholder={t.dietPlan.kcal} className="sm:col-span-1 mt-1 block w-full px-2 py-1 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm text-sm" />
                        <button type="button" onClick={() => removeSnack(index)} className="sm:col-span-1 text-red-500 hover:text-red-700 disabled:opacity-50" disabled={plan.snacks.length <=1}>
                            <Icons.X className="h-4 w-4 mx-auto"/>
                        </button>
                    </div>
                ))}
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.editDietPlanModal.summary}</label>
                <textarea
                name="summary"
                rows={3}
                value={plan.summary}
                onChange={(e) => setPlan(prev => ({...prev, summary: e.target.value}))}
                placeholder={t.editDietPlanModal.summaryPlaceholder}
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                />
            </div>
          
            <div className="mt-6 flex justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-slate-700 flex-shrink-0">
                <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-md">
                {t.common.cancel}
                </button>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md">
                {t.common.savePlan}
                </button>
            </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default EditDietPlanModal;