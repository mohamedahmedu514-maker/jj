// NutriTrack Health Management System - Created by Anas Bahaa
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Icons from './Icons';
import { translations, Language } from '../translations';


interface OnboardingStep {
  title: string;
  content: string;
}

interface OnboardingGuideProps {
  steps: OnboardingStep[];
  onComplete: () => void;
  isOpen: boolean;
  lang: Language;
}

const OnboardingGuide: React.FC<OnboardingGuideProps> = ({ steps, onComplete, isOpen, lang }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const t = translations[lang];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  const step = steps[currentStep];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/70 flex items-center justify-center z-[100] p-4"
        >
          <motion.div
            key={currentStep}
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="bg-background dark:bg-dark-secondary rounded-2xl shadow-xl w-full max-w-md p-6 relative"
          >
            <div className="flex items-center mb-4">
              <div className="bg-primary/10 text-primary p-2 rounded-full me-3">
                <Icons.Trophy className="h-6 w-6" />
              </div>
              <h2 className="text-xl font-bold text-foreground dark:text-dark-foreground">{step.title}</h2>
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6">{step.content}</p>
            <div className="flex justify-between items-center">
              <button
                onClick={handleSkip}
                className="text-sm font-medium text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
              >
                {t.onboarding.skip}
              </button>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-400">
                  {currentStep + 1} / {steps.length}
                </span>
                <button
                  onClick={handleNext}
                  className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md"
                >
                  {currentStep === steps.length - 1 ? t.onboarding.finish : t.onboarding.next}
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default OnboardingGuide;