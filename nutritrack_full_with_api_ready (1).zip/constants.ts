// NutriTrack Health Management System - Created by Anas Bahaa
import { ActivityLevel } from './types';

export const ACTIVITY_LEVEL_OPTIONS = [
  { value: ActivityLevel.SEDENTARY, label: 'Sedentary (little or no exercise)' },
  { value: ActivityLevel.LIGHTLY_ACTIVE, label: 'Lightly active (light exercise/sports 1-3 days/week)' },
  { value: ActivityLevel.MODERATE, label: 'Moderately active (moderate exercise/sports 3-5 days/week)' },
  { value: ActivityLevel.VERY_ACTIVE, label: 'Very active (hard exercise/sports 6-7 days a week)' },
];

export const ACTIVITY_MULTIPLIERS: Record<ActivityLevel, number> = {
  [ActivityLevel.SEDENTARY]: 1.2,
  [ActivityLevel.LIGHTLY_ACTIVE]: 1.375,
  [ActivityLevel.MODERATE]: 1.55,
  [ActivityLevel.VERY_ACTIVE]: 1.725,
};

export const BMI_CATEGORIES = {
  UNDERWEIGHT: {
    label: 'Underweight',
    range: [0, 18.5],
    color: 'text-blue-500',
    suggestion: 'Focus on a high-calorie, protein-rich diet to build mass.'
  },
  NORMAL: {
    label: 'Normal weight',
    range: [18.5, 24.9],
    color: 'text-green-500',
    suggestion: 'Maintain a balanced diet to stay in a healthy range.'
  },
  OVERWEIGHT: {
    label: 'Overweight',
    range: [25, 29.9],
    color: 'text-yellow-500',
    suggestion: 'Consider a low-carb, calorie-deficit diet to manage weight.'
  },
  OBESE: {
    label: 'Obese',
    range: [30, Infinity],
    color: 'text-red-500',
    suggestion: 'Adopt a low-carb, high-protein diet with significant calorie restriction.'
  },
};