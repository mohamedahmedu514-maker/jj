// NutriTrack Health Management System - Created by Anas Bahaa
import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { PatientProfile } from '../db';
import Icons from '../components/Icons';
import { Appointment } from '../types';
import { translations, Language } from '../translations';

interface DoctorDashboardPageProps {
  patients: PatientProfile[];
  onSelectPatient: (patient: PatientProfile) => void;
  onAddPatient: () => void;
  onLogout: () => void;
  lang: Language;
  setLang: (lang: Language) => void;
}

const UpcomingAppointments: React.FC<{patients: PatientProfile[], lang: Language}> = ({patients, lang}) => {
    const t = translations[lang];
    const allAppointments = useMemo(() => {
        const appointmentsWithPatient = patients.flatMap(patient => 
            (patient.appointments || []).map(app => ({...app, patientName: patient.data.name}))
        );

        return appointmentsWithPatient
            .filter(app => new Date(app.date) >= new Date())
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
            .slice(0, 5); // Get the next 5 appointments
    }, [patients]);
    
    return (
        <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg">
            <h3 className="font-semibold text-foreground dark:text-dark-foreground flex items-center mb-2">
                <Icons.CalendarDays className="h-5 w-5 me-2 text-primary" />
                {t.doctorDashboard.upcomingAppointments}
            </h3>
            {allAppointments.length > 0 ? (
                 <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-2">
                    {allAppointments.map(app => (
                         <li key={app.id} className="p-2 bg-white dark:bg-slate-700 rounded">
                            <p className="font-bold text-foreground dark:text-dark-foreground">{app.patientName}</p>
                            <p>{new Date(app.date).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US', { dateStyle: 'medium', timeStyle: 'short' })}</p>
                        </li>
                    ))}
                </ul>
            ) : (
                 <p className="text-xs text-gray-500 dark:text-gray-400 text-center py-4">{t.doctorDashboard.noAppointments}</p>
            )}
        </div>
    )
}

const DoctorDashboardPage: React.FC<DoctorDashboardPageProps> = ({ patients, onSelectPatient, onAddPatient, onLogout, lang, setLang }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const t = translations[lang];
  
  const toggleLanguage = () => {
    setLang(lang === 'en' ? 'ar' : 'en');
  };

  const filteredPatients = patients.filter(patient =>
    patient.data.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getTimeAgo = (dateString: string) => {
      const date = new Date(dateString);
      const now = new Date();
      const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

      const rtf = new Intl.RelativeTimeFormat(lang, { numeric: 'auto' });

      let interval = seconds / 31536000;
      if (interval > 1) return rtf.format(-Math.floor(interval), 'year');
      interval = seconds / 2592000;
      if (interval > 1) return rtf.format(-Math.floor(interval), 'month');
      interval = seconds / 86400;
      if (interval > 1) return rtf.format(-Math.floor(interval), 'day');
      interval = seconds / 3600;
      if (interval > 1) return rtf.format(-Math.floor(interval), 'hour');
      interval = seconds / 60;
      if (interval > 1) return rtf.format(-Math.floor(interval), 'minute');
      return rtf.format(-Math.floor(seconds), 'second');
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-secondary dark:bg-dark-background p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-3xl bg-background dark:bg-dark-secondary rounded-2xl shadow-xl p-6 sm:p-8 relative"
      >
        <div className="absolute top-6 left-6 sm:top-8 sm:left-8 flex items-center">
            <button
                onClick={onLogout}
                className="flex items-center p-2 me-4 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-full"
                aria-label="Back to login"
            >
                <Icons.ArrowLeft className={`h-5 w-5 ${lang === 'ar' ? 'transform rotate-180' : ''}`} />
            </button>
            <div>
                <h2 className="text-lg sm:text-xl font-bold text-primary">{t.doctorName}</h2>
                <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">{t.systemName}</p>
            </div>
        </div>
        <div className="absolute top-6 right-6 sm:top-8 sm:right-8">
            <button onClick={toggleLanguage} className="p-2 rounded-full text-gray-500 hover:bg-gray-200 dark:text-gray-400 dark:hover:bg-slate-700 font-bold text-sm">
                {lang === 'en' ? 'ع' : 'EN'}
            </button>
        </div>
        
        <div className="text-center mb-8 pt-16 sm:pt-20">
          <Icons.BookUser className="mx-auto h-12 w-12 text-primary" />
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground dark:text-dark-foreground mt-4">{t.doctorDashboard.title}</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">{t.doctorDashboard.subtitle}</p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-6">
            <div className="flex-grow">
                <div className="relative mb-4">
                <Icons.Search className="absolute start-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                    type="text"
                    placeholder={t.doctorDashboard.searchPlaceholder}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full ps-10 pe-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg shadow-sm bg-white dark:bg-slate-700 text-foreground dark:text-dark-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
                </div>

                <div className="space-y-3 max-h-72 overflow-y-auto pr-2">
                {filteredPatients.length > 0 ? (
                    filteredPatients.map((patient) => (
                    <motion.button
                        key={patient.data.id}
                        whileHover={{ scale: 1.02, x: lang === 'en' ? 5 : -5 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => onSelectPatient(patient)}
                        className="w-full text-left flex items-center p-3 border border-gray-300 dark:border-slate-600 rounded-lg shadow-sm bg-white dark:bg-slate-700 hover:bg-gray-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-light transition-all duration-200"
                    >
                        <div className="bg-primary/10 text-primary p-3 rounded-full me-4">
                            <Icons.User className="h-6 w-6" />
                        </div>
                        <div className="flex-grow">
                            <p className="font-semibold text-md text-foreground dark:text-dark-foreground">{patient.data.name}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">{t.doctorDashboard.id}: {patient.data.id} &bull; {t.doctorDashboard.lastUpdated}: {getTimeAgo(patient.progressHistory[patient.progressHistory.length-1].date)}</p>
                        </div>
                        <div className="text-right">
                             <p className="text-sm font-medium text-foreground dark:text-dark-foreground">{patient.data.weight} {t.progressChart.kg}</p>
                             <p className="text-xs text-gray-500 dark:text-gray-400">{t.doctorDashboard.weight}</p>
                        </div>
                    </motion.button>
                    ))
                ) : (
                    <p className="text-center text-gray-500 dark:text-gray-400 py-4">{t.doctorDashboard.noPatients}</p>
                )}
                </div>
            </div>
            <div className="md:w-1/3 flex-shrink-0 space-y-4">
                 <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={onAddPatient}
                    className="w-full flex items-center justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-light transition-colors duration-300"
                    >
                    <Icons.Plus className="h-5 w-5 me-3" />
                    {t.doctorDashboard.addPatient}
                </motion.button>
                <UpcomingAppointments patients={patients} lang={lang} />
            </div>
        </div>
      </motion.div>
    </div>
  );
};

export default DoctorDashboardPage;