// NutriTrack Health Management System - Created by Anas Bahaa
import React from 'react';
import { motion } from 'framer-motion';
import { PatientProfile } from '../db';
import { UserRole } from '../types';
import Dashboard from '../components/Dashboard';
import { Language } from '../translations';

interface PatientDashboardPageProps {
  patientProfile: PatientProfile;
  userRole: UserRole;
  onUpdateProfile: (updatedProfile: PatientProfile) => void;
  onLogout: () => void;
  onBackToPatients?: () => void;
  onBack?: () => void;
  showOnboarding: boolean;
  onOnboardingComplete: () => void;
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  lang: Language;
  setLang: (lang: Language) => void;
}

const PatientDashboardPage: React.FC<PatientDashboardPageProps> = (props) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Dashboard {...props} />
    </motion.div>
  );
};

export default PatientDashboardPage;