// NutriTrack Health Management System - Created by Anas Bahaa
import { GoogleGenAI, Type } from "@google/genai";
import { UserData, DietPlan, DietPreferences, Gender } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const dietPlanSchema = {
  type: Type.OBJECT,
  properties: {
    breakfast: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING, description: "Name of the breakfast meal." },
        description: { type: Type.STRING, description: "A brief description of the breakfast meal." },
        calories: { type: Type.NUMBER, description: "Estimated calories for the breakfast meal." },
      },
      required: ['name', 'description', 'calories'],
    },
    lunch: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING, description: "Name of the lunch meal." },
        description: { type: Type.STRING, description: "A brief description of the lunch meal." },
        calories: { type: Type.NUMBER, description: "Estimated calories for the lunch meal." },
      },
       required: ['name', 'description', 'calories'],
    },
    dinner: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING, description: "Name of the dinner meal." },
        description: { type: Type.STRING, description: "A brief description of the dinner meal." },
        calories: { type: Type.NUMBER, description: "Estimated calories for the dinner meal." },
      },
      required: ['name', 'description', 'calories'],
    },
    snacks: {
      type: Type.ARRAY,
      description: "A list of one or two snacks for the day.",
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "Name of the snack." },
          description: { type: Type.STRING, description: "A brief description of the snack." },
          calories: { type: Type.NUMBER, description: "Estimated calories for the snack." },
        },
        required: ['name', 'description', 'calories'],
      },
    },
    summary: { type: Type.STRING, description: "A brief summary of the overall diet plan and its goals." },
  },
  required: ['breakfast', 'lunch', 'dinner', 'snacks', 'summary'],
};

export const generateDietPlan = async (
  userData: UserData,
  preferences: DietPreferences,
  dailyCalories: number
): Promise<DietPlan> => {
  const { age, gender, height, weight, activityLevel } = userData;
  const { allergies, dietaryRestrictions, cuisinePreferences, dislikes } = preferences;

  const genderText = gender === Gender.MALE ? 'male' : 'female';

  const prompt = `
    Generate a detailed one-day diet plan for a ${age}-year-old ${genderText}, who is ${height}cm tall, weighs ${weight}kg, and has a "${activityLevel.replace('_', ' ')}" activity level.
    The target daily calorie intake is approximately ${dailyCalories} kcal.

    The plan must be tailored to the following preferences:
    - Allergies: ${allergies || 'None'}
    - Dietary Restrictions: ${dietaryRestrictions || 'None'}
    - Cuisine Preferences: ${cuisinePreferences || 'Any'}
    - Foods to Dislike/Avoid: ${dislikes || 'None'}

    Please provide a balanced and healthy meal plan with specific meal names, brief descriptions, and estimated calorie counts for breakfast, lunch, dinner, and one or two snacks. Also include a brief, encouraging summary of the diet plan.
    The total calories for all meals combined should be close to the target of ${dailyCalories} kcal.
    The response must be in JSON format and adhere to the provided schema.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: dietPlanSchema,
      },
    });

    const jsonText = response.text.trim();
    const generatedPlan = JSON.parse(jsonText);
    
    // Basic validation to ensure the structure is correct
    if (generatedPlan.breakfast && generatedPlan.lunch && generatedPlan.dinner && Array.isArray(generatedPlan.snacks)) {
      return generatedPlan as DietPlan;
    } else {
      throw new Error('AI response did not match the expected format.');
    }

  } catch (error)  {
    console.error('Error generating diet plan with Gemini:', error);
    if (error instanceof Error) {
        throw new Error(`Failed to generate diet plan. AI service error: ${error.message}`);
    }
    throw new Error('An unknown error occurred while generating the diet plan.');
  }
};
